# Weather-Journal App Project

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI.
It takes data from the user; city Zip code and his feelings, the app retrieves zip code data from OpenWeatherApp Api key and returnns temperature and current date to the user. 

## Instructions to test the app
In order to test the app you should:
1- Install express, cors and body parser package from the terminal by typing this code in the terminal (npm install express cors body-parser)
2- To check that localhost is running on port 5500 write in the terminal (node server.js)
3-open the index.html in live server
4- write in the browser url area localhost:5500
5-write your city zip code and your feelings in their text areas