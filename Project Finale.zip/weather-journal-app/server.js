// Require Express & our Dependencies; bodyParser & Cors
const express = require('express');
const bodyParser = require('body-parser')
const cors = require('cors');

// Start up an instance of app
const app = express();

/* Dependencies */
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));

// Setup Server
const port = 5500;

// Spin up the server in the form of arrow function
// Callback to debug (write node server.js in the terminal to check which port is running in the localhost)
const server = app.listen(port, ()=>{
    console.log("running on localhost : " + port)
});

// Setup empty JS object to act as endpoint for all routes
const projectData = {};

// Respond with JS object when a GET request is made to the apppage
app.get('/allData', function (_request, response) {
        response.send(projectData);
    });

// Post Route
app.post('/addData', function (request, _response) {
    console.log(request.body)
    userData = {
        temp: request.body.temp,
        date: request.body.date,
        content: request.body.content
    }
    projectData.push(userData)
});
