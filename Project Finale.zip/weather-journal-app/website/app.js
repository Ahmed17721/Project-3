// Personal API Key for OpenWeatherMap API
const baseUrl = 'http://api.openweathermap.org/data/2.5/weather?zip='
const apikey = '&appid=8292b6f6429dfd78c5b46cfe5be375bc'

/* Global Variables */
const zip = document.getElementById('zip');
const feelings = document.getElementById('feelings');
const dateCode = document.getElementById('date');
const tempCode = document.getElementById('temp');
const contentCode = document.getElementById('content');

// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click', performAction);

/* /* Function called by event listener */
function performAction() {
    const zip = document.getElementById('zip').value;
    const feelings = document.getElementById('feelings').value;
    getData(baseUrl,zip,apikey)
    .then(function(data){
        console.log(data)
        postData('/addData', {date:newDate, temp:data.main.temp, content:feelings.value})
    })
    .then(
      updateUI()
    )
};

/* Function to GET Web API Data*/
const getData = async (baseURL,zip,key)=>{
    const res = await fetch(baseURL+zip+key)
    try {
        const data = await res.json();
        console.log(data)
        return data;
    }catch(error) {
      console.log("error", error);
      // appropriately handle the error
    }
}

/* Function to POST data */
const postData = async ( url = '', data = {})=>{
    console.log(data);
      const response = await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
     // Body data type must match "Content-Type" header        
      body: JSON.stringify(data), 
    });
    try {
        const newData = await response.json();
        console.log(newData);
        return newData;
    }catch(error) {
      console.log("error", error);
    } 
}

/* Function to GET Project Data (Update UI) */
const updateUI = async () => {
    const request = await fetch('/allData');
    try{
        const allData = await request.json();
        dateCode.innerHTML = `Date: ${data.date}`;
        tempCode.innerHTML = `Temp: ${data.temp}`;
        contentCode.innerHTML = `My Feelings: ${data.content}`;
    }catch(error){
      console.log("error", error);
    }
}

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();